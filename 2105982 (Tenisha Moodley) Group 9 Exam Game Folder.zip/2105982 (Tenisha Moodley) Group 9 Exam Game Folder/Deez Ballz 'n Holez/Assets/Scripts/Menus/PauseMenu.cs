﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using UnityEngine.UI;

public class PauseMenu : MonoBehaviour
{

    //public TargetAndShootController tsc;
    //allow unity to access pause button directly
    //public Button PauseButton;

    /// <summary>
    /// accessable and,
    /// static to check from other scripts whether or not the game is paused because,
    /// (don't really want to access this specific method)
    /// </summary>
    public static bool isPaused = false;

    /// <summary>
    /// game object that allows main canvas in game script to access the EscapeGameUI panel 
    /// that holds the pause, escape and resume buttons
    /// </summary>
    public GameObject pausedMenuUi;

    //calls the on click button event
    public void Update()
    {
        //PauseButton.onClick.AddListener(TaskOnClick);
        if (Input.GetKeyDown(KeyCode.Escape))
        {

            if (isPaused)
            {
                Resume();
                //tgt.enabled = true;
            }
            else
            {
                Pause();
                //tgt.enabled = false;
            }
        }
    }

    /// <summary>
    /// if game is paused then the game will pause but 
    /// if the game is not paused then the game will resume
    /// Was not efficient because of the lack of cursor on screen
    /// </summary>
    public void TaskOnClick()
    {

        if (isPaused)
        {
            Resume();
        }
        else
        {
            Pause();
        }

    }


    /// <summary>
    /// Opposite of Paused method 
    /// accessable resume button interaction
    /// </summary>
    public void Resume()
    {

        pausedMenuUi.SetActive(false);
        //onlyOnceMouseDown();
        Time.timeScale = 1f;
        isPaused = false;
        AudioListener.pause = false;


    }

    /// <summary>
    /// When game is pasued, we want puse menu to appear
    /// game to freeze
    /// change isPaused variable to true
    /// </summary>
    void Pause()
    {

        pausedMenuUi.SetActive(true);
        Time.timeScale = 0f;
        isPaused = true;
        AudioListener.pause = false;

    }

    /// <summary>
    /// accessable menu button interaction
    /// time.timeScale = 1f allows game to load in realtime 
    /// </summary>
    public void loadHomePage()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("HomePage");
        AudioListener.pause = false;
    }

    /*public void onlyOnceMouseDown()
    {
        if (Input.GetMouseButton(0))
        {
            Time.timeScale = 1f;
        }
    }*/

}