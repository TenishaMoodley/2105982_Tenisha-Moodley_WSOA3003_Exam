﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class MainMenu : MonoBehaviour
{

    public GameObject WonUI;

    public Animator CamAnim;
    public bool playing;

    public GameObject AbilityBall;
    public GameObject ObjectiveBall;

    public AbilityBallController ABC;

    public StrokeController sc;

    // public AbilityBallController AbilityBallController;

    private void Start()
    {

        //CamAnim = GameObject.Find("Main Camera").GetComponent<Animator>();

        //WonUI.SetActive(true);
        CamAnim.SetBool("Pan", false);
        playing = false;
        AudioListener.pause = false;
    }


    /// <summary>
    /// loads home page from buildIndex first and then loads game when play button is pressed
    /// </summary>
    public void play()
    {
        Time.timeScale = 1f;

        playing = true;
        CamAnim.SetBool("Pan", playing);

        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        WonUI.SetActive(false);
        
        AudioListener.pause = false;

        AbilityBall.GetComponent<TargetAndShootController>().enabled = true;
        ObjectiveBall.GetComponent<TargetAndShootController>().enabled = false;

        ABC.glowAB.SetActive(true);
        ABC.glowOB.SetActive(false);

        sc.strokeCounter = 0;


        //AbilityBallController.WhichBallActive();
    }

    public void Continue()
    {
        Time.timeScale = 1f;

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        AudioListener.pause = false;

    }


    /// <summary>
    /// Allow player to completely exit game
    /// </summary>
    public void exitGameCompletely()
    {

        Debug.Log("Quiting game...");
        Application.Quit();
    }

    /// <summary>
    /// allows players to interact with the play button in the EndGame window,
    /// and allow them to restart the game
    /// </summary>
    public void resetGame()
    {
        Time.timeScale = 1f;
        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Scene scene = SceneManager.GetActiveScene(); 
        SceneManager.LoadScene(scene.name);
        AudioListener.pause = false;
    }

    public void PreviousLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
        AudioListener.pause = false;
    }

    public void Home()
    {
        SceneManager.LoadScene("Scene 1");
    }

    public void level1()
    {
        SceneManager.LoadScene("Level 1");
    }

    public void level2()
    {
        SceneManager.LoadScene("Level 2");
    }

    public void level3()
    {
        SceneManager.LoadScene("Level 3");
    }

    public void level4()
    {
        SceneManager.LoadScene("Level 4");
    }

    public void level5()
    {
        SceneManager.LoadScene("Level 5");
    }

    public void credits()
    {
        SceneManager.LoadScene("Credits");
    }
}
