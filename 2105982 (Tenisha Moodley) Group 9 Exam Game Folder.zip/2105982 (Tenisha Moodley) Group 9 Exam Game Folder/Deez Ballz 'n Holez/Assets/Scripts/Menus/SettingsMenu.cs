﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class SettingsMenu : MonoBehaviour
{

    public Slider currVolume;

    public AudioSource music;

    /// <summary>
    /// allows player to change volume of music in settings menu through slider
    /// </summary>
    public void Update()
    {
        music.volume = currVolume.value;
    }


}