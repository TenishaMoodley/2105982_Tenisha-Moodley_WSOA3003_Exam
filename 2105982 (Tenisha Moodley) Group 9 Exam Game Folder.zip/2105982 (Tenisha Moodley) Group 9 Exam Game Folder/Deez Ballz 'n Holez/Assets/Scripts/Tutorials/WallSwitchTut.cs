﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallSwitchTut : MonoBehaviour
{
    public Animator WallSwitchAnim;
    public WallSwitchController WallSwitch;

    private void Start()
    {
       // WallSwitch = GetComponent<WallSwitchController>();
        WallSwitchAnim.SetBool("TutPlaying", true);
    }

    private void Update()
    {
        if (WallSwitch.WSHasBeenActivated == true)
        {
            WallSwitchAnim.SetBool("TutPlaying", false);
        }
    }
}
