﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchTut : MonoBehaviour
{
    public Animator SwitchAnim;

    private void Start()
    {
        SwitchAnim.SetBool("TutPlaying", true);
    }

    private void Update()
    {
        if (Input.GetButtonDown("Normal") || Input.GetButtonDown("Phase"))
        {
            SwitchAnim.SetBool("TutPlaying", false);
        }
    }
}
