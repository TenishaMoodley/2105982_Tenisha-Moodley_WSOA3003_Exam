﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(LineRenderer))] //makes sure the line renderer is awoken because sometimes the awake function starts before
public class LineTrajectoryController : MonoBehaviour
{
    LineRenderer LineRenderer;

    public void Awake()
    {
        LineRenderer = GetComponent<LineRenderer>();

    }

    /// <summary>
    /// Defines start and end points and allows points to be created
    /// </summary>
    public void RendLine(Vector3 startingPoint, Vector3 endingPoint)
    {
        LineRenderer.positionCount = 2;
        Vector3[] linePoints = new Vector3[2];
        linePoints[0] = startingPoint;
        linePoints[1] = endingPoint;

        //will add in the two points for us
        LineRenderer.SetPositions(linePoints);

    }

    /// <summary>
    /// Ends the line after the player has mouse button up
    /// </summary>
    public void EndsLine()
    {
        LineRenderer.positionCount = 0;
    }
}
