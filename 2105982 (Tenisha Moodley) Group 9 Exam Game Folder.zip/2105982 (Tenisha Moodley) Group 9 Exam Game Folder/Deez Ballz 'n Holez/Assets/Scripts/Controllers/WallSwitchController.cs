﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallSwitchController : MonoBehaviour
{
    public bool WSHasBeenActivated;
    public Animator WallSwitchAnim;

    private void Start()
    {
        WallSwitchAnim.SetBool("Activated", false);
        WSHasBeenActivated = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AbilityBall" || collision.gameObject.tag == "ObjectiveBall")
        {
            WSHasBeenActivated = true;
            WallSwitchAnim.SetBool("Activated", true);
        }
        else
        {
            WSHasBeenActivated = false;
            WallSwitchAnim.SetBool("Activated", false);
        }
    }
}
