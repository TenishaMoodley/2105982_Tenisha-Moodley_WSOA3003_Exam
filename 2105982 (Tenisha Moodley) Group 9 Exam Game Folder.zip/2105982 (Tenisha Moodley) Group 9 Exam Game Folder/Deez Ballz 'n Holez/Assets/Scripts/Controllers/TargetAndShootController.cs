﻿

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TargetAndShootController : MonoBehaviour
{
    //Ability Balls
    //public int NormalCounter, StickyCounter, PhaseCounter, BreakCounter;

    //Objective Ball
    public int OBCounter;

    //access trajectory line code
    LineTrajectoryController TrajectoryLine;

    public AbilityBallController AbilityBallController;

    public StrokeController StrokeController;

    //To make sure that while any menu is active, the cursor is visable and the mouse click does not have multiple functions 
    PauseMenu Pause;

    //Power of ball shooting
    public float Power;

    //Rigidbody of the ball
    public Rigidbody2D BallRigidbody;

    //Min and Max power for the drag
    public Vector2 MinPower;
    public Vector2 MaxPower;

    //need to access the main camera to follow movement and see movement through world view
    Camera Camera;

    //Starting and ending points of the drag to calculate the power and force of the drag
    Vector2 Force;
    Vector3 StartingPoint;
    Vector3 EndingPoint;

    //Animation for cue stick hitting ball
    Animator anim;

    //Player Turn
    public bool Player1Turn;

    //LineRenderer lr;

    /// <summary>
    /// make sure the cursor is not visable on screen
    /// </summary>
    public void Start()
    {
        Camera = Camera.main;

        //Player1Turn = true;
        //Player2Turn = false;

        anim = GetComponent<Animator>();
        Pause = GetComponent<PauseMenu>();

        TrajectoryLine = GetComponent<LineTrajectoryController>();

    }


    /// <summary>
    /// Mouse to game object movement and direction through world view and camera
    /// </summary>
    void Update()
    {
        Vector2 almostStopped = new Vector2(40f, 40f);

        if (Pause == false && BallRigidbody.velocity == Vector2.zero)
        {
            //Cursor.visible = false;

            //force stop
            if (BallRigidbody.velocity == almostStopped)
            {
                BallRigidbody.velocity = Vector2.zero;
            }

            //Parenthesis 0 is the left mouse trigger
            if (Input.GetMouseButtonDown(0))
            {

                StartingPoint = gameObject.transform.position;
                StartingPoint.z = 15; //Prevent the shooting line from dissapearing behind other game objects

            }

            /// <summary>
            /// if the mouse is held down, so therefore not just the up or down
            /// </summary>
            if (Input.GetMouseButton(0))
            {
                Vector3 PointDraggedTo = Camera.ScreenToWorldPoint(Input.mousePosition);
                PointDraggedTo.z = 15;
                TrajectoryLine.RendLine(StartingPoint, PointDraggedTo); //from where the ball is to where you dragged to

                /*Vector2[] predictionLine = Prediction(BallRigidbody, (Vector2)transform.position, BallRigidbody.velocity, 500);

                 lr.positionCount = predictionLine.Length;

                Vector3[] positions = new Vector3[predictionLine.Length];

                for(int i = 0; i < predictionLine.Length; i++)
                {
                    positions[i] = predictionLine[i];
                }
                lr.SetPositions(positions);*/
            }




           /* if (Input.GetMouseButtonUp(0))
            {
               // StartCoroutine("WaitForSeconds");

            }*/

            if (Input.GetMouseButtonUp(0))
            {
                StrokeController.strokeCounter++;


                EndingPoint = Camera.ScreenToWorldPoint(Input.mousePosition);
                EndingPoint.z = 15;


                Force = new Vector2(

                    Mathf.Clamp(StartingPoint.x - EndingPoint.x, MinPower.x, MaxPower.x),
                    Mathf.Clamp(StartingPoint.y - EndingPoint.y, MinPower.y, MaxPower.y)

                    );

                //Shoots the ball
                BallRigidbody.AddForce(Power * Force, ForceMode2D.Impulse);


                //ends the shooting line 
                TrajectoryLine.EndsLine();


                //counter
                if (AbilityBallController.AbilityBall.GetComponent<TargetAndShootController>().enabled == true && AbilityBallController.ability == AbilityBallController.ABILITY.NORMAL 
                    || AbilityBallController.AbilityBall.GetComponent<TargetAndShootController>().enabled == true && AbilityBallController.ability == AbilityBallController.ABILITY.BREAK)
                {
                    AbilityBallController.AbilityBallCounter--;
                    //AbilityBallController.ABCounterText.text = "no. of shots: " + AbilityBallController.AbilityBallCounter;
                    //ChooseBallController.AbilityBallCounterText = AbilityBallCounter + "";
                }

                if (AbilityBallController.ObjectiveBall.GetComponent<TargetAndShootController>().enabled == true)
                {
                    AbilityBallController.ObjectiveBallCounter--;
                    //AbilityBallController.OBCounterText.text = "no. of shots: " + AbilityBallController.ObjectiveBallCounter;

                }
            }
        }
        else if (Pause == true && BallRigidbody.velocity == Vector2.zero)
        {
            //Cursor.visible = true;


        }

    }

    /*public Vector2[] Prediction(Rigidbody2D rb, Vector2 pos, Vector2 velocity, int steps)
    {
        Vector2[] results = new Vector2[steps];

        float timestep = Time.fixedDeltaTime / Physics2D.velocityIterations;
        Vector2 gravityAccel = Physics2D.gravity * rb.gravityScale * timestep * timestep;

        float drag = 1f - timestep * rb.drag;
        Vector2 moveStep = velocity * timestep;

        for (int i = 0; i < steps; i++)
        {
            moveStep += gravityAccel;
            moveStep *= drag;
            pos += moveStep;
            results[i] = pos;
        }

        return results;
    }*/

    /*IEnumerator WaitForSeconds()
    {
        yield return new WaitForSeconds(3);

        if (Player1Turn == true)
        {
            Player1Turn = false;
           
            //FindObjectOfType<AudioManager>().Play("NextPlayerTurn");

        }
        else if (Player1Turn == false)
        {
            Player1Turn = true;
            
           // FindObjectOfType<AudioManager>().Play("NextPlayerTurn");

        }
    }*/

}