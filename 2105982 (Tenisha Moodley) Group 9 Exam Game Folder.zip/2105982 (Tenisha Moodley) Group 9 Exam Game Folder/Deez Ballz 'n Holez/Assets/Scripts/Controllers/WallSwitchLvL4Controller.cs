﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallSwitchLvL4Controller : MonoBehaviour
{
    public bool WSHasBeenActivatedLvL4;
    public Animator WallSwitchAnimLvL4;

    private void Start()
    {
        WallSwitchAnimLvL4.SetBool("Activated", false);
        WSHasBeenActivatedLvL4 = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AbilityBall" || collision.gameObject.tag == "ObjectiveBall")
        {
            WSHasBeenActivatedLvL4 = true;
            WallSwitchAnimLvL4.SetBool("Activated", true);
        }
        else
        {
            WSHasBeenActivatedLvL4 = false;
            WallSwitchAnimLvL4.SetBool("Activated", false);
        }
    }
}
