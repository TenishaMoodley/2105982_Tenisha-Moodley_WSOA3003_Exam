﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StrokeController : MonoBehaviour
{
    public int strokeCounter;
    public int parCount;

    public TMP_Text StrokeText;
    public TMP_Text ParText;

    public float Timer;
    public TMP_Text TimerText;

    private void Start()
    {
        StrokeText.text = "Strokes:" + strokeCounter;
        ParText.text = "Par:" + parCount;
    }


    private void Update()
    {
        StrokeText.text = "Strokes:" + strokeCounter;

   
        //StartCoroutine("timer");
    }

   /* IEnumerator timer()
    {
        yield return new WaitForSeconds(4f);

        Timer += Time.deltaTime;
        TimerText.text = "Timer: " + Timer.ToString("F2");
    }*/

}
