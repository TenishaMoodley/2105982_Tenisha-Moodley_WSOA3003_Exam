﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    public bool IsTouchingWall = false;

    public GameObject AbilityBall;

    public AbilityBallController ABC;

    public Transform ChildsOldTransform;

        private void Start()
    {
        //Store Transform before it becomes the child
        ChildsOldTransform.localScale = new Vector2(0.8f, 0.8f);
        transform.localScale = ChildsOldTransform.localScale;
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "StickyWall" && ABC.ability == AbilityBallController.ABILITY.STICKY)
        {
            Debug.Log(IsTouchingWall);
            IsTouchingWall = true;

        }

        if (collision.gameObject == AbilityBall && ABC.ability == AbilityBallController.ABILITY.STICKY)                  //if sticky is on the platform, then she becomes a child of the platform
        {
            AbilityBall.transform.parent = transform;

            //Then when it becomes the the child try the following:
            transform.GetChild(0).localScale = new Vector2(3.77f, -0.24f);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject == AbilityBall && ABC.ability != AbilityBallController.ABILITY.STICKY)                  //if not sticky  then she no longer is a child of the platform
        {
            AbilityBall.transform.parent = null;

            //Store Transform before it becomes the child
            transform.localScale = ChildsOldTransform.localScale;
        }
    }
}
