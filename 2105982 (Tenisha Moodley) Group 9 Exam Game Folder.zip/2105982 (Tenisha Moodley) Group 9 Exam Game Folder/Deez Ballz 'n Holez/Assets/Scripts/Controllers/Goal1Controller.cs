﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Goal1Controller : MonoBehaviour
{
    public AbilityBallController ABC;
    public GameObject AfterScoreUI;

    public GameObject wellDone;
    public GameObject almostThere;

    public StrokeController sc;

    private void Start()
    {
        ABC.hasWon = false;
        wellDone.SetActive(false);
        almostThere.SetActive(false);
    }

    private void Update()
    {
        if (sc.strokeCounter == sc.parCount)
        {
            wellDone.SetActive(true);
            almostThere.SetActive(false);
        }
        else if (sc.strokeCounter > sc.parCount)
        {
            wellDone.SetActive(false);
            almostThere.SetActive(true);
        }
        else if (sc.strokeCounter < sc.parCount)
        {
            wellDone.SetActive(true);
            almostThere.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "ObjectiveBall")
        {
            AfterScoreUI.SetActive(true);
            ABC.hasWon = true;
        }
        
    }
}
