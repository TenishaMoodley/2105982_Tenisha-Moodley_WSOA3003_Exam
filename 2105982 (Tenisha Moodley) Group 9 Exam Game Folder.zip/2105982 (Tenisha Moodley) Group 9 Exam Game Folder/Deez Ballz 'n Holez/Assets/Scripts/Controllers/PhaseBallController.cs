﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhaseBallController : MonoBehaviour
{

    public GameObject PhaseBall;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("SolidWall"))
        {
            PhaseBall.GetComponent<CircleCollider2D>().enabled = false;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("SolidWall"))
        {
            PhaseBall.GetComponent<CircleCollider2D>().enabled = true;
        }
    }
}
