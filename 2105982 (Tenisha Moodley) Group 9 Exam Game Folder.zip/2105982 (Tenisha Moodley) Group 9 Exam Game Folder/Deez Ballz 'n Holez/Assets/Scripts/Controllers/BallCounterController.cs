﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallCounterController : MonoBehaviour
{
    public AbilityBallController AbilityBallCounter;

    public GameObject[] Counters;


    private void Update()
    {
        for (int i = 0; i < Counters.Length; i++)
        {
            /*if ()
            {
                AbilityBallCounter.AbilityBallCounter
            }*/
        }
       
    }
}
