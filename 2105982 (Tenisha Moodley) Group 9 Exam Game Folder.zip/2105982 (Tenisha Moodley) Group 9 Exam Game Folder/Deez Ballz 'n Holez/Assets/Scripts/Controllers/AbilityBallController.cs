﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class AbilityBallController : MonoBehaviour
{
    //states
    public enum ABILITY { NORMAL, PHASETHROUGH, STICKY, BREAK }
    public ABILITY ability;


    //Objects
    public Rigidbody2D ObjectiveRB;
    public Rigidbody2D AbilityRB;
    public GameObject AbilityBall;
    public GameObject ObjectiveBall;
    public GameObject[] PhaseWalls;
    public GameObject[] StickyWalls;
    public GameObject glowOB;
    public GameObject glowAB;
    

    //UI
    public GameObject OBUI, NBUI, PBUI, SBUI, ABNoMoreUI, OBNoMoreUI, LoseUI;


    //counters
    public int AbilityBallCounter;
    public int ObjectiveBallCounter;
    public int WhichBallInUse;
    public bool hasWon;
    public TMP_Text ABCounterText;
    public TMP_Text OBCounterText;


    private void Start()
    {
        Normal();

        ObjectiveRB = GameObject.Find("Objective Ball").GetComponent<Rigidbody2D>();
        AbilityRB = this.GetComponent<Rigidbody2D>();

        PhaseWalls = GameObject.FindGameObjectsWithTag("PhaseWall");
        StickyWalls = GameObject.FindGameObjectsWithTag("StickyWall");

        LoseUI.SetActive(false);

        WhichBallInUse = 0;

    }

    private void Update()
    {
        WhichBallActive();
        ChangeAbility();
    }



    public void WhichBallActive()
    {
        //Objective Ball
        if (ObjectiveBall.GetComponent<TargetAndShootController>().enabled == true && ObjectiveBallCounter > 0) //gives OB the script and ensures that it has available shots
        {
            //Ability Ball does not have the script
            AbilityBall.GetComponent<TargetAndShootController>().enabled = false;
            WhichBallInUse = 1; //1 is the OB

            //UI
            OBUI.SetActive(true);
            OBNoMoreUI.SetActive(false);
            ABNoMoreUI.SetActive(false);
            PBUI.SetActive(false);
            NBUI.SetActive(false);
            SBUI.SetActive(false);
            ABCounterText.text = "";
            OBCounterText.text = "PP: " + ObjectiveBallCounter;

            //Objects
            glowOB.SetActive(true);
            glowAB.SetActive(false);

            Debug.Log("Objective  with shots");

        }
        else if (ObjectiveBall.GetComponent<TargetAndShootController>().enabled == true && ObjectiveBallCounter <= 0 && AbilityBallCounter > 0) //OB has the script but it has no shots left
        {
            ObjectiveBall.GetComponent<TargetAndShootController>().enabled = false; //Removing the scrpit from OB

            WhichBallInUse = 2; //2 is the AB
            AbilityBall.GetComponent<TargetAndShootController>().enabled = true; //AB now gets the script

            //Objects
            glowOB.SetActive(false);
            glowAB.SetActive(true);


            ObjectiveBall.GetComponent<LineTrajectoryController>().enabled = false;
            ObjectiveBall.GetComponent<LineRenderer>().enabled = false;

            OBNoMoreUI.SetActive(true);
            ABNoMoreUI.SetActive(false);
            ABCounterText.text = "";
            OBCounterText.text = "";


            Debug.Log("Objective No shots");
        }

        //Ability Ball
        else if (AbilityBall.GetComponent<TargetAndShootController>().enabled == true && AbilityBallCounter > 0)
        {
            ObjectiveBall.GetComponent<TargetAndShootController>().enabled = false;
            WhichBallInUse = 2;

            OBUI.SetActive(false);
            OBNoMoreUI.SetActive(false);
            ABNoMoreUI.SetActive(false);
            ABCounterText.text = "PP: " + AbilityBallCounter;
            OBCounterText.text = "";


            //Objects
            glowOB.SetActive(false);
            glowAB.SetActive(true);

            Debug.Log("Ability with shots");
        }

        else if (AbilityBall.GetComponent<TargetAndShootController>().enabled == true && AbilityBallCounter <= 0 && ObjectiveBallCounter > 0)
        {
            AbilityBall.GetComponent<TargetAndShootController>().enabled = false;

            WhichBallInUse = 1;
            ObjectiveBall.GetComponent<TargetAndShootController>().enabled = true;

            //Objects
            glowOB.SetActive(true);
            glowAB.SetActive(false);

            AbilityBall.GetComponent<LineTrajectoryController>().enabled = false;
            AbilityBall.GetComponent<LineRenderer>().enabled = false;
            ABNoMoreUI.SetActive(true);
            OBNoMoreUI.SetActive(false);
            ABCounterText.text = "";
            OBCounterText.text = "";


            Debug.Log("Ability No shots");
        }

        //Neither have shots
        else if (AbilityBallCounter <= 0 && ObjectiveBallCounter <= 0 && hasWon == false)
        {
            StartCoroutine("WaitForBall");

            OBNoMoreUI.SetActive(true);
            ABNoMoreUI.SetActive(true);
            OBUI.SetActive(false);
            PBUI.SetActive(false);
            NBUI.SetActive(false);
            SBUI.SetActive(false);
            ABCounterText.text = "";
            OBCounterText.text = "";

            WhichBallInUse = 0;

            AbilityBall.GetComponent<TargetAndShootController>().enabled = false;
            ObjectiveBall.GetComponent<TargetAndShootController>().enabled = false;

            //Objects
            glowOB.SetActive(false);
            glowAB.SetActive(false);

            Debug.Log("No Objective No Ability");

        }
    }



    public void ChangeAbility()
    {
        Vector2 still = new Vector2(0f, 0f);

        //scenes
        Scene Scene1 = SceneManager.GetSceneByName("Scene 1");
        Scene Level1 = SceneManager.GetSceneByName("Level 1");
        Scene Level2 = SceneManager.GetSceneByName("Level 2");
        Scene Level3 = SceneManager.GetSceneByName("Level 3");
        Scene Level4 = SceneManager.GetSceneByName("Level 4");
        Scene Level5 = SceneManager.GetSceneByName("Level 5");


        if (ObjectiveRB.velocity == still && AbilityRB.velocity == still && Scene1.isLoaded == true || ObjectiveRB.velocity == still && AbilityRB.velocity == still && Level1.isLoaded == true)
        {
            OnlyNormal();
        }
        else if (ObjectiveRB.velocity == still && AbilityRB.velocity == still && Level2.isLoaded == true || ObjectiveRB.velocity == still && AbilityRB.velocity == still && Level3.isLoaded == true) 
        {
            NormalAndPhase();
        }
        else if (ObjectiveRB.velocity == still && AbilityRB.velocity == still && Level4.isLoaded == true || ObjectiveRB.velocity == still && AbilityRB.velocity == still && Level5.isLoaded == true)
        {
            AllAbilities();
        }

    }

    public void Normal()
    {
        this.GetComponent<SpriteRenderer>().color = new Color(0, 166, 255, 255);
        ability = ABILITY.NORMAL;
        Debug.Log("ability selected: " + ability);
        NBUI.SetActive(true);
        PBUI.SetActive(false);
        SBUI.SetActive(false);
        OBNoMoreUI.SetActive(false);
        ABNoMoreUI.SetActive(false);

        PhaseWall();
    }

    public void Phase()
    {
        this.GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 255);
        ability = ABILITY.PHASETHROUGH;
        Debug.Log("ability selected: " + ability);
        PBUI.SetActive(true);
        NBUI.SetActive(false);
        SBUI.SetActive(false);
        OBNoMoreUI.SetActive(false);
        ABNoMoreUI.SetActive(false);


        PhaseWall();
    }

    public void Sticky()
    {
        this.GetComponent<SpriteRenderer>().color = new Color(0, 255, 0, 255);
        ability = ABILITY.STICKY;
        Debug.Log("ability selected: " + ability);
        SBUI.SetActive(true);
        NBUI.SetActive(false);
        PBUI.SetActive(false);
        OBNoMoreUI.SetActive(false);
        ABNoMoreUI.SetActive(false);

        PhaseWall();

    }


    //On Collision
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Vector2 stick = new Vector2(0f, 0f);

        //Sticky Ball
        if (collision.gameObject.tag == "StickyWall" && ability == ABILITY.STICKY)
        {
            AbilityRB.velocity = stick;
            //AbilityBallCounter--;
        }

    }


    //Phase Ball
    public void PhaseWall()
    {
        for (int i = 0; i < PhaseWalls.Length; i++)
        {
           

            if (ability != ABILITY.PHASETHROUGH)
            {
                Debug.Log("Phase not active");
                Physics2D.IgnoreCollision(PhaseWalls[i].GetComponent<BoxCollider2D>(), GetComponent<CircleCollider2D>(), false);
                PhaseWalls[i].GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 255);

            }
            else if (ability == ABILITY.PHASETHROUGH)
            {
                Physics2D.IgnoreCollision(PhaseWalls[i].GetComponent<BoxCollider2D>(), GetComponent<CircleCollider2D>(), true);
                //AbilityBallCounter--;
                Debug.Log("Phase is active");
                PhaseWalls[i].GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 127);
            }
        }
    }


    //Only Normal Active
    public void OnlyNormal()
    {
        if (Input.GetButtonDown("Normal"))
        {
            Normal();
        }
    }

    //Normal and Phase active
    public void NormalAndPhase()
    {
        if (Input.GetButtonDown("Normal"))
        {
            Normal();
        }

        if (Input.GetButtonDown("Phase"))
        {
            Phase();
        }
    }


    //All ability balls Active
    public void AllAbilities()
    {
        if (Input.GetButtonDown("Normal"))
        {
            Normal();
        }

        if (Input.GetButtonDown("Phase"))
        {
            Phase();
        }

        if (Input.GetButtonDown("Sticky"))
        {
            Sticky();
        }
    }

    IEnumerator WaitForBall()
    {
        yield return new WaitForSeconds(4f);

        LoseUI.SetActive(true);

        
    }
}
